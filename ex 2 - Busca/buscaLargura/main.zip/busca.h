//EDSON YUDI TOMA - 9791305
#ifndef BUSCA_H
#define BUSCA_H

#include "matriz.h"

int buscaL(MATRIX*, int, int);

#endif
